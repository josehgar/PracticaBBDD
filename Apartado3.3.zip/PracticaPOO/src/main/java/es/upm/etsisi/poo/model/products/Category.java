package es.upm.etsisi.poo.model.products;

public enum Category {
    MERCH,
    STATIONERY,
    CLOTHES,
    BOOK,
    ELECTRONICS,
    EVENT
}