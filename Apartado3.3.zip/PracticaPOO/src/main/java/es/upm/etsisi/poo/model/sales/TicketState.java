package es.upm.etsisi.poo.model.sales;

public enum TicketState {
    EMPTY,
    OPEN,
    CLOSE
}