import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.*;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            System.out.println("Error: "+ ex +". No se ha podido inicializar el driver");}
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "");
            System.out.println("Conexion con exito");
        } catch (SQLException ex) {
            System.out.println("No se ha podido conectar a la base de datos. Error: "+ex);
        }
        String instruccion=null;
        Statement stmt = null;
        ResultSet rs = null;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Introduce un id para buscar las prescripciones de un paciente o exit para salir");
            instruccion=sc.nextLine();
            if (!Objects.equals(instruccion, "exit")){
                try {
                    instruccion="select * from vista_patient where patient_id="+instruccion;
                    if (conn != null)
                    stmt = conn.createStatement();
                    rs = stmt.executeQuery(instruccion);
                    if (!rs.next()) {
                        System.out.println("No se existe prescripcion para ese usuario");
                    } else {
                        exportarXML(rs,sc);
                    }
                } catch (SQLException ex){
                    System.out.println("Error de sql "+ex+", no se ha podido realizar la consulta");
                }
            }
        } while (!Objects.equals(instruccion, "exit"));





    }

    public static void exportarXML(ResultSet rs, Scanner sc){

        StringBuilder lineaDevuelta= new StringBuilder();
        lineaDevuelta.append("<prescripciones>\n");
        System.out.println("¿Que nombre deseas ponerle al archivo?");
        BufferedWriter bw=null;
        try{
            bw=new BufferedWriter(new FileWriter(sc.nextLine()+".xml"));
            try {
                do {
                    lineaDevuelta.append("      <prescripcion>\n");
                    lineaDevuelta.append("          <codigoMedicacion>").append(String.valueOf(rs.getInt("codigo_medicacion"))).append("</codigoMedicacion>\n");
                    lineaDevuelta.append("          <nombreMedicamento>").append((rs.getString("nombre_medicacion"))).append("</nombreMedicamento>\n");
                    lineaDevuelta.append("          <marcaMedicamento>").append((rs.getString("marca_medicacion"))).append("</marcaMedicamento>\n");
                    lineaDevuelta.append("          <nombrePaciente>").append((rs.getString("nombre_paciente"))).append("</nombrePaciente>\n");
                    lineaDevuelta.append("          <fechaPrescripcion>").append(String.valueOf(rs.getString("fecha_prescripcion"))).append("</fechaPrescripcion>\n");
                    lineaDevuelta.append("          <nombreMedico>").append((rs.getString("nombre_doctor"))).append("</nombreMedico>\n");
                    lineaDevuelta.append("      </prescripcion>\n");
                }while (rs.next());
                rs.close();
                bw.write(lineaDevuelta.toString());
            }catch (Exception ex){
                System.out.println("El cursor ha dado el siguiente error: "+ex);
            }
            bw.write("</prescripciones>\n");
            bw.close();
        } catch (Exception e) {
            System.out.println("Error creando el flujo de escritura: "+e);
        }
    }
}
